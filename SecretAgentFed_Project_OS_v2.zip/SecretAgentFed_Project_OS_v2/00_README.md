# SECRETAGENTFED PROJECT OPERATING SYSTEM — v2.0

## Purpose
This is the consolidated operating state for **The Tayyite Succession: How Muhammad Came to Power**.

It is deliberately deeper than the earlier Control Pack. The goal is not merely to summarize the thesis. The goal is to let a new agent enter the project with the same *recoverable research architecture* now available from the Perplexity export, Correction Ledger, Atlas materials, publication corpus, and session archive.

## Core rule
**Never confuse what the project believes, what a source says, what an agent inferred, and what Perplexity merely surfaced.**

Every important item belongs to one of four states:

1. **RAW / RECOVERED** — directly present in a file, URL ledger, publication, or session artifact.
2. **CONTROLLED** — explicitly indexed or corrected in the Correction Ledger / Atlas / controlled research files.
3. **RECONSTRUCTED** — a structural interpretation assembled from multiple controlled items.
4. **INFERENTIAL / OPEN** — a hypothesis, proposed mechanism, or unresolved identification.

## Non-negotiables
- Raw URLs and raw strings are immutable.
- 577 reference occurrences ≠ 577 verified sources.
- 315 distinct exact raw strings and 185 candidate resources are reconstruction statistics, not proof of reading.
- A URL's presence does not prove that Perplexity opened or read the resource.
- Same name ≠ same person.
- Same genealogy ≠ same political role.
- Network connection ≠ centralized command.
- Inscription date ≠ proposed historical-event date.
- Reported evidence ≠ independently controlled evidence.
- Silence ≠ proof of absence.
- Competing witnesses stay competing unless a locked correction resolves them.
- Project publications are **internal evidence**, not independent corroboration.

## What changed from the earlier packs
This version adds a formal state architecture, Perplexity-session reconstruction, source-state hierarchy, publication evolution map, machine-readable Correction Ledger index, machine-readable 577-reference PDF control extraction, explicit uncertainty classes, and a separation between the historical model and the forensic reconstruction of the research operation.

## Start here
1. `01_MASTER_STATE_V2.md`
2. `02_EVIDENCE_AND_SOURCE_HIERARCHY.md`
3. `04_PERPLEXITY_OPERATION_RECONSTRUCTION_V2.md`
4. `05_PERPLEXITY_SESSION_MAP.md`
5. `06_PUBLICATION_EVOLUTION_MAP.md`
6. `07_CURRENT_PUBLICATION_STATE.md`
7. `10_CORRECTION_LEDGER_OPERATING_STATE_V2.md`
8. `11_ATLAS_OPERATING_STATE_V2.md`
9. `23_AGENT_OPERATING_PROTOCOL_V2.md`
10. `25_FINAL_AGENT_BOOT_PROMPT_V2.md`

The `99_RECOVERED_ARTIFACTS` directory is the custody layer. The machine-readable directory is a derivative/control layer and must never overwrite the recovered originals.
