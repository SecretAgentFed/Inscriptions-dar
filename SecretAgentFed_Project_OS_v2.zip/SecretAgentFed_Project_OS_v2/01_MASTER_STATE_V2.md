# MASTER PROJECT STATE — v2.0

## Project
**The Tayyite Succession: How Muhammad Came to Power** — SecretAgentFed.

## Central research problem
Reconstruct the early Arab political-religious succession/network behind later Islamic narrative formation while keeping separate the axes of **title, person, office, seat, and locus** and separating contemporaneous evidence from later memory.

## Working historical architecture
The project investigates a political sequence centered on Muhammad → Abū Bakr → ʿUmar → ʿUthmān → Muʿāwiya, while asking whether later prophetic biography compressed a more distributed frontier political history into a sacred founder narrative.

The principal geographic architecture currently under investigation is:
- al-Ḥīra — frontier political/administrative center and transition zone
- Medina — later religious/political center in the project model
- Mecca — sacred/home axis
- Damascus — Muʿāwiya-era imperial capital
- Jerusalem — ceremonial/sacred authority axis in the Muʿāwiya material

## Core analytical models
- **Absorption Principle:** defeated or displaced networks may survive through personnel, households, property, marriage, protection, fiscal representation, military incorporation, or memory.
- **Office → Household → Network → Function:** continuity at one level does not prove continuity at another.
- **Institutional Displacement (DR-I):** population/function may survive while institutional seat or form changes.
- **Network ≠ centralized organization.**
- **Memory fragments by institution:** courts, tribes, churches, monasteries, poetry, archaeology, schools, and external chronicles preserve different edges.

## Major controlled branches
1. House of Iyas / al-Ḥīra
2. Hāniʾ / Qabīṣa prosopography
3. Farwah / Bayān / Iyās transmission problem
4. Twelve-Year Gap c.618–633
5. 633 surrender and absorption
6. Tayyite northern corridor / ʿAdī b. Ḥātim
7. Southern covenant / Raḥmānān / Abraha
8. External witnesses and non-Muslim succession lists
9. Medina / Salʿ / early physical memory
10. Coins / titles / king → prophet transition
11. Muʿāwiya / Jerusalem / Damascus
12. Female political and institutional networks
13. Hīra archaeological/object corpus
14. AtlasEvidence and epigraphic control

## Current strongest unresolved problems
- Full prosopographical separation of Iyas, Qays, Farwah, Ḥayyah and Hāniʾ.
- Bayān vs Iyās textual/genealogical witness and the transmission path.
- Exact status of the 618–633 information gap.
- Relative weight of competing 633 surrender variants.
- Independent external-witness chronology and title language.
- How much continuity can be demonstrated without converting network survival into centralized command.

## Current publication state
The public archive has advanced through **LXXVIII. THE MANY SUCCESSIONS OF AL-ḤĪRA**. Recent entries LXXIV–LXXVIII function increasingly as explicit control/reconciliation/synthesis documents rather than merely narrative installments. See `06_PUBLICATION_EVOLUTION_MAP.md` and `07_CURRENT_PUBLICATION_STATE.md`.

## Research-state distinction
The historical thesis is **not** the same thing as the recovered Perplexity state. This OS stores both, and keeps their provenance separate.
