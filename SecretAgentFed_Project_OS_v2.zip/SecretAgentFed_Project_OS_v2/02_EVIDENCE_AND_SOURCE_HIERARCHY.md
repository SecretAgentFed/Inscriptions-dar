# EVIDENCE AND SOURCE HIERARCHY

## A. Custody hierarchy
When two statements conflict, first ask which layer they belong to.

**Tier 0 — Raw artifact**
PDF bytes, extracted text, raw URL, manuscript image, scan, original publication text.

**Tier 1 — Direct controlled evidence**
A source passage, inscription, object record, explicit genealogical statement, dated external notice, or other directly inspectable evidence.

**Tier 2 — Controlled synthesis**
Atlas cards, Correction Ledger statements, evidence matrices, prosopographical tables, or a synthesis that explicitly cites Tier 1 evidence.

**Tier 3 — Project interpretation**
Absorption Principle, distributed frontier model, transmission model, institutional-displacement model.

**Tier 4 — Hypothesis / reconstruction**
Claims requiring further testing or comparison.

## B. Status vocabulary
- **A / Direct:** source directly attests the proposition.
- **B / Supported synthesis:** multiple controlled facts support the proposition, but the proposition itself is not directly stated by a source.
- **C / Unresolved:** competing readings, insufficient evidence, or identity/date uncertainty.
- **C1:** explicit locked correction.
- **C2:** competing indexing/witnesses retained.
- **C3:** reconstructive preference, not a correction.

## C. Source-state labels
Every important source/resource should carry one of:
- IDENTIFIED
- LOCATED
- OPENED
- EXTRACTED
- PASSAGE-CONTROLLED
- CLAIM-LINKED
- COUNTEREVIDENCE-REVIEWED
- UNRESOLVED
- REJECTED / NONRELEVANT

Never upgrade IDENTIFIED → OPENED merely because a URL is present.

## D. Independent corroboration rule
Internal SecretAgentFed publications can show the project's reasoning history. They cannot independently corroborate a historical proposition.

## E. Negative controls
Every major research branch should record at least one plausible but rejected merger or interpretation.
