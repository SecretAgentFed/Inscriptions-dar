# STATE MODEL AND DATA FLOW

## Master chain
**RAW ARTIFACT → SOURCE/RESOURCE → PASSAGE → CLAIM → EVIDENCE GRADE → INTERPRETATION → COUNTEREVIDENCE → STATUS → PUBLICATION**

## Parallel forensic chain
**PERPLEXITY ACTION → QUERY → RESULT → OPENED RESOURCE → EXTRACTED PASSAGE → INTERMEDIATE CLAIM → FOLLOW-UP SEARCH → FINAL SYNTHESIS**

The two chains must not be merged.

A historical claim can be strong while the Perplexity action that surfaced it remains uncertain.
Conversely, a Perplexity action can be directly recovered while the historical proposition it produced remains weak.

## Required IDs
Use stable IDs whenever possible:
- `SRC-` source/resource
- `PASS-` passage
- `CLM-` project claim
- `Q-` research question
- `COR-` correction
- `AT-` Atlas evidence item
- `PUB-` publication
- `PXP-` Perplexity action/reconstruction item
- `NEG-` negative control
- `REL-` relationship/edge

## Relationship types
attests / contradicts / qualifies / derives-from / depends-on / same-as / candidate-same-as / separate-from / cites / reproduces / corrects / supersedes / unresolved-with

## Prohibition
Do not use a single “source supports claim” field without recording the passage and status. That field hides too much provenance.
