# PERPLEXITY OPERATION RECONSTRUCTION — v2

## Objective
Recover what Perplexity actually did during the research operation, not what an ideal research agent should have done.

## Directly recovered
The export contains the user's original instructions, Perplexity's visible responses, a 577-occurrence reference layer, and project-facing summaries. A separate visible-session archive contains recoverable draft/research material and a reconstruction of the session state.

## Strong structural findings
- The operation began by inspecting the SecretAgentFed Substack and describing the project around XLV–XLVIII.
- It was explicitly instructed to familiarize itself with the Correction Ledger and Evidence Atlas.
- It was then instructed to read the entire series and build a knowledge base of thesis evolution.
- It was instructed to create agent files, priority research leads, open-question cleanup, a catch-up file, future release recommendations, and operating protocols.
- The reference layer subsequently expanded to 577 raw occurrences.
- The reference layer includes SecretAgentFed publications, scholarly resources, archives, government databases, generic Substack/navigation pages, and unrelated/noisy links.

## What is NOT established merely by the export
- That every 577 URL occurrences were opened.
- That every 185 candidate resources were read.
- That every historical claim in the Perplexity synthesis was source-controlled.
- That the order of URLs equals the exact order of research actions.
- That repeated URLs represent repeated substantive reading rather than export/generation loops.

## Reconstruction levels
**Level 1 — Direct:** visible prompt, visible response, explicit URL, explicit passage, explicit action.

**Level 2 — Structural reconstruction:** repeated URL blocks, source clusters, query/result relationships, likely branch loops.

**Level 3 — Historical inference:** claims about what the research operation “must have meant” or what a source “proves.” Level 3 is prohibited from being presented as recovered fact.

## Perplexity state map
### Phase A — Project discovery
Substack profile / early series entries / initial thesis.

### Phase B — Control-asset ingestion
Correction Ledger + Evidence Atlas requested as project memory/control infrastructure.

### Phase C — Full-series instruction
User explicitly requested release-by-release knowledge accumulation and thesis evolution.

### Phase D — Agent infrastructure
Priority leads, unanswered questions, catch-up file, release roadmap, protocols.

### Phase E — Broad reference expansion
577 URL/reference occurrences, including repeated blocks and noise.

### Phase F — Later synthesis
The visible session archive contains increasingly detailed Iyas, al-Ḥīra, covenant, external-witness, Medina, Muʿāwiya, and succession reconstructions.

## Critical forensic conclusion
The recovered Perplexity state is best understood as a **research architecture plus a partially recoverable research trace**, not as a complete replay of every browsing action.
