# PERPLEXITY SESSION MAP

## Recoverable research themes
The visible session archive shows substantial work beyond the early “project overview.” Major threads include:

### al-Ḥīra / Iyas
Iyas b. Qabīṣa, Āzāḏbeh, Naḵīragān, ʿAyn al-Tamr, Dū Qār, White Palace, 633 surrender, fiscal terms, intelligence clauses, and the relationship between office and surviving household/network.

### Frontier information networks
Local elites, negotiated surrender, gate-opening, taxation, guides, intelligence, and the proposition that conquest could redirect existing information capacity rather than destroy it.

### Southern covenant
Himyar, Raḥmānān, Abraha, southern Abrahamic political vocabulary, and possible northward reformulation. These remain research questions, not automatic derivations.

### Medina covenant
Constitution of Medina, political covenant, Jewish-identifying groups, and the separation of political membership from later confessional categorization.

### Prophet / king problem
The session explored a possible distinction between sacred authority and military/political command after a founder's death. This is a reconstruction model, not a directly attested constitutional description.

### Muʿāwiya / Jerusalem / Damascus
Maronite Chronicle material was used to distinguish sacred/ceremonial Jerusalem from Damascus as political seat and to reconsider the role of an earlier capital such as al-Ḥīra.

## Methodological evolution visible in the archive
The research moved from “who was the founder?” toward:
1. distributed frontier political structures;
2. personnel and household survival;
3. institutional continuity without dynastic continuity;
4. transmission instability;
5. later historiographical re-indexing;
6. control of competing evidence rather than forced harmonization.

## Important caution
Some passages in the session archive are themselves polished analytical reconstructions. They should not be treated as equivalent to primary-source extraction simply because they occur in a recovered draft.
