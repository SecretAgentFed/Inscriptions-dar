# PUBLICATION EVOLUTION MAP

## Earlier architecture
The recovered session archive shows a major early arc around XLI–XLVIII, including:
- Family / gates / local networks
- Musaylima / Raḥmān / Bakr corridor
- Serjeant / composite covenant
- Twelve-Year Gap / consolidation
- Collective kingdom / sacred seat / king

## Middle architecture
The project then deepened into:
- ʿAdī b. Ḥātim and the northern Tayyite corridor
- Hāniʾ / Qabīṣa
- House of Iyas
- Farwah / al-Ḥīra
- female networks
- external witnesses
- Atlas / Correction Ledger infrastructure

## Current architecture
The recent public arc is visibly more self-auditing:
- LXVIII — THE HOUSE HISTORY HAD TO FORGET
- LXIX — THE HOUSE THAT BECAME ANOTHER HOUSE
- LXX — WHAT WAS THE POEM ANSWERING
- LXXI — THE BAYĀN TREE
- LXXII — WHEN THE IMAGE BECAME A NAME
- LXXIII — THE WESTWARD EYE
- LXXIV — MASTER STATEMENT OF KNOWN FACTS
- LXXV — THE RELIGIOUS WARRIOR
- LXXVI — THE KĀHINA AND THE PROPHETESS
- LXXVII — THE CORRECTION LEDGER
- LXXVIII — THE MANY SUCCESSIONS OF AL-ḤĪRA

## Interpretation
The series has shifted from primarily reconstructive narrative toward **evidence architecture and controlled synthesis**. LXXIV and LXXVII are especially important because they explicitly function as control documents. LXXVIII appears to return the control architecture to the central al-Ḥīra/succession problem.

This is a publication-state observation, not a claim that every earlier thesis has been proven.
