# CURRENT PUBLICATION STATE — 8 OCTOBER 2026

The public SecretAgentFed archive currently displays LXXVIII as the newest series entry, followed by LXXVII through LXVIII in descending order.

The current visible sequence is:
- LXXVIII. THE MANY SUCCESSIONS OF AL-ḤĪRA
- LXXVII. THE CORRECTION LEDGER
- LXXVI. THE KĀHINA AND THE PROPHETESS
- LXXV. THE RELIGIOUS WARRIOR
- LXXIV. MASTER STATEMENT OF KNOWN FACTS
- LXXIII. THE WESTWARD EYE
- LXXII. WHEN THE IMAGE BECAME A NAME
- LXXI. THE BAYĀN TREE
- LXX. WHAT WAS THE POEM ANSWERING
- LXIX. THE HOUSE THAT BECAME ANOTHER HOUSE
- LXVIII. THE HOUSE HISTORY HAD TO FORGET

Source: public archive checked 8 October 2026.

Navigation URL: https://secretagentfed.substack.com/archive

Use the archive for navigation only. Controlled claims must come from the publication files and evidence records in the project corpus.
