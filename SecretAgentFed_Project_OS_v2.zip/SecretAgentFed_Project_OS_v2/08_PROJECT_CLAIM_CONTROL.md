# PROJECT CLAIM CONTROL

## Master claim families

### C1 — Succession
Working sequence: Muhammad → Abū Bakr → ʿUmar → ʿUthmān → Muʿāwiya.

### C2 — Distributed political formation
The project investigates whether early Arab political authority emerged through surviving frontier networks rather than a fully isolated Hijazi creation.

### C3 — Absorption
Conquest may preserve and redirect local personnel, fiscal knowledge, households and institutions.

### C4 — House of Iyas
The Iyas household remains a major controlled case of office/household/network/function divergence across the Sasanian-to-Medinan transition.

### C5 — Bayān / Iyās
The Bayān witness must remain meaningful until full textual/genealogical collation resolves its status.

### C6 — Covenant / sacred authority
The project investigates whether covenantal and sacred authority were formulated across multiple earlier political-religious environments and later consolidated into Islamic memory.

### C7 — External witnesses
Syriac/Greek/Armenian/epigraphic/numismatic evidence should initially be used for what it directly says—titles, rulers, places, events—before importing later theological categories.

### C8 — Institutional continuity
Political succession, ecclesiastical succession, educational succession and household continuity are separate variables.

## Claim-writing rule
Every publication-ready claim must be expressible as:
**Claim → direct evidence → why it supports the claim → strongest counterevidence → grade → remaining uncertainty.**
