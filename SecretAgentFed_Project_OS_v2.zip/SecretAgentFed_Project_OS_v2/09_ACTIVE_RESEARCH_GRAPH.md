# ACTIVE RESEARCH GRAPH

## RED — immediate research value
1. House of Iyas full prosopography.
2. 618–633 gap.
3. Farwah / Bayān / Iyās textual collation.
4. 633 surrender variant comparison.
5. External early witnesses to Muhammad/title/succession.
6. Perplexity 577-resource provenance reconstruction.
7. Correction Ledger ↔ Atlas ↔ publication claim reconciliation.

## AMBER — high value, controlled expansion
8. Lakhmid institutional continuity.
9. Medina physical evidence.
10. Coins/title transition.
11. Muʿāwiya / Jerusalem / Damascus.
12. Hyecho and eastern external witnesses.
13. Female network cases.
14. Hīra object corpus.
15. Southern Raḥmānān / Abraha / covenant vocabulary.

## GREEN — background only
Generic history, broad comparative theology, generic Substack/AI/evidence-management material, and sources without a direct connection to a live project question.

## Stop rule
If a new search does not change a named open question, correct a controlled error, add direct evidence, or materially strengthen a counterargument, stop.
