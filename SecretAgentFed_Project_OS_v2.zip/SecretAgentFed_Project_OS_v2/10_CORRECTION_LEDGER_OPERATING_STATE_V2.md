# CORRECTION LEDGER OPERATING STATE — CL001–CL680

## Function
The Correction Ledger is a **distinct control archive**, not an Atlas Annex. It records corrections, competing readings, negative controls, identity rules, institutional-continuity controls, and unresolved transmission problems.

## Domain map recovered
1. CL001–125 — Source & Identity Controls
2. CL126–250 — Political Transition
3. CL251–375 — House of Iyas / Bayān
4. CL376–411 — Four Castles / Overlapping Jurisdictions
5. CL412–500 — German / French Historiography
6. CL501–532 — Epigraphy / Architecture
7. CL533–625 — Church / Bishops / Schools
8. CL626–639 — Christian Plurality
9. CL640–657 — Ṭayy / Tanukh Ecclesiastical Network
10. CL658–680 — Georgius / Institutional Displacement

## Locked control examples
- Same narrative ≠ same person.
- Same genealogy ≠ same political role.
- Network connection ≠ political alignment.
- Later genealogy cannot automatically be projected backward.
- Political and ecclesiastical succession require separate models.
- Bayān / Iyās remains unresolved.
- Farwah remains a person-index problem until the chronology/transmission is controlled.
- Ruqāsh is a negative control.
- Georgius is explicitly locked as Bishop of the Arabs at al-ʿAqūlā, not ordinary al-Ḥīra episcopal succession.
- Political Ṭayy and ecclesiastical Ṭayy convergence is a candidate intersection, not automatic identity.
- Institutional displacement is a hypothesis/model, not automatic proof of institutional transfer.

## Operating rule
A new finding that conflicts with CL-locked material must be reported as a contradiction/review request, not silently substituted into the model.

See machine-readable index: `98_MACHINE_READABLE/Correction_Ledger_CL001_CL680_INDEX.csv`.
