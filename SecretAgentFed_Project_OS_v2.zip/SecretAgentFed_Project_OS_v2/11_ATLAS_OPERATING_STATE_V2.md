# ATLAS OPERATING STATE — v2

## Role
AtlasEvidence is the project's evidence-navigation and source-control environment. It is not identical to the Correction Ledger.

## Evidence grades
- A — direct
- B — supported interpretation
- C — unresolved / competing

## Atlas control principles
- cited ≠ extracted
- reported ≠ controlled
- inscription date ≠ proposed historical date
- same name ≠ same person
- network ≠ centralized command
- geographic proximity ≠ institutional identity
- institutional continuity ≠ political continuity

## Major Atlas branches
- Medina / Salʿ / Sadd al-Khanaq / Wādī Rānūnā
- al-Ḥīra / Christian institutional network
- epigraphy
- churches / bishops / schools
- female institutional memory
- Tayy / Tanukh ecclesiastical intersection
- institutional displacement

## Required Atlas return
For every future Atlas investigation report:
1. object/source ID
2. exact source
3. direct observation
4. transcription/translation if applicable
5. date as reported
6. independent dating basis
7. proposed date, if any, separately
8. grade
9. counterevidence
10. unresolved fields
