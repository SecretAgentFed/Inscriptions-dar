# HOUSE OF IYAS — CONTROLLED STATE

## Strong current structure
Iyas b. Qabīṣa al-Ṭāʾī is securely relevant to the al-Ḥīra/Sasanian frontier problem. The 633 material places Iyas and/or Farwah within the local negotiating elite across variant transmissions.

## Core controls
- Iyas ≠ Āzāḏbeh.
- Office succession ≠ disappearance of household.
- House of Iyas ≠ entire Christian elite of al-Ḥīra.
- White Palace association is important but does not automatically prove citywide command.
- Farwah must be tracked separately from Iyas.
- Ḥayyah remains less densely controlled.
- Qays b. Qabīṣa is a strong brother candidate in the literary tradition.
- Umāma bint Masʿūd is a maternal/household lead, not a universal bridge.
- Hāniʾ must not be casually fused with the Iyas cluster.

## Working interpretation
The strongest model is selective survival of a political household across regime change, with continuity of representation/property/local knowledge stronger than proof of continuous formal office.

## Open work
- Complete occurrence map for Iyas/Qays/Farwah/Ḥayyah.
- Variant-by-variant 633 surrender comparison.
- White Palace source chain.
- Early Kūfa/post-conquest careers.
- Exact relationship between poetic and conquest traditions.
