# FARWAH / BAYĀN / IYĀS — LOCKED CONTROL

## Core problem
Abū Zubayd's elegy preserves a reading associated with **Āl Bayān** where the received tradition later gives **Āl Iyās**. This is not to be dismissed as a mere scribal error until the textual witnesses are fully collated.

## Controlled points
- Ibn Barrī's note identifies Farwah b. Iyās b. Qabīṣa and associates him with al-Ḥīra.
- Farwah appears in surrender material with variant indexing.
- “Dead at conquest” versus later Farwah material is an unresolved transmission/person-index problem.
- Bayān is a meaningful witness.
- Later correction/replacement of Bayān with Iyās is not, by itself, proof of deliberate erasure.
- Banū Bayān must not be equated with Buqayla without independent evidence.
- Ḥayya / Ḥayyān / Hāya remains a possible ancestral bridge, not a conclusion.

## Explicitly excluded
- The B/H phonetic-drift tangent.
- Medina tangent.
- Any claim that Bayān = Buqayla.
- Any claim of deliberate genealogical erasure without direct evidence.

## Highest-value next step
Produce a witness table for every occurrence of Farwah, Bayān, Iyās and Ḥayyah, with exact wording, source, edition, page, transmission context, and relationship to the poem.
