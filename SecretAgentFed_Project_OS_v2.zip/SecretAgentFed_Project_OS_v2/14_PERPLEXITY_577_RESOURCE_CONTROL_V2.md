# PERPLEXITY 577-REFERENCE CONTROL

## Forensic numbers
- 577 raw occurrences
- 315 distinct exact raw strings
- 231 singleton strings
- 45 strings occurring twice
- 12 strings occurring three times
- 27 strings occurring four or more times
- maximum exact repetition: 6
- 10 symbolic/unresolved records (`$=79`, `$=208`, `$=50`, `$=275`, `=306`, etc.)
- 47 unique anomalous occurrence IDs
- 64 anomaly features
- 12 Level-2 structural variant relationships
- 185 candidate underlying resources

## Page control
Occurrences appear on 17 of 19 pages; pages 3 and 4 are empty of reference occurrences in the recovered ledger.

## Important anomalies
- embedded whitespace in URLs
- truncated URLs
- parameter fragmentation
- signed Substack CDN URL
- Microsoft `4ble` preserved exactly
- Cambridge UUID truncation candidate
- CIA URL truncation/complete-variant cluster
- SEC truncations
- MIT `api $i=v2$` vs `api=v2`
- unresolved symbolic pointers

## Identity rule
Candidate resource clustering is Level 2. It does not prove source opening or reading.

## Machine-readable derivative
`98_MACHINE_READABLE/Perplexity_577_Reference_PDF_Extraction_CONTROL.csv` is a PDF-extraction control copy. It is **not** a replacement for the user's authoritative raw 577-row ledger.
