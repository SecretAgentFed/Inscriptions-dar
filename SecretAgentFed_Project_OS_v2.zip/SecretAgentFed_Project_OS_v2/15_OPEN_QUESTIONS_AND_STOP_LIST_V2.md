# OPEN QUESTIONS + STOP LIST

## Highest priority
Q-01 What exactly is the prosopographical relationship among Iyas, Qays, Farwah and Ḥayyah?
Q-02 What do all 633 surrender variants actually say?
Q-03 How does the Bayān witness relate to the later Āl Iyās witness?
Q-04 What can be directly controlled about the 618–633 gap?
Q-05 Which external notices independently constrain the succession/title chronology?
Q-06 Which elements of the Perplexity 185-resource set were actually opened/read?
Q-07 Which current publication claims remain unsupported after Atlas/Correction Ledger reconciliation?

## Medium priority
Q-08 Lakhmid institutional continuity.
Q-09 Hīra churches/bishops/schools as independent institutional-memory streams.
Q-10 Medina physical-memory chronology.
Q-11 coin/title transition.
Q-12 Jerusalem/Damascus/Muʿāwiya chronology.
Q-13 eastern witnesses including Hyecho.
Q-14 female-network comparative cases.

## Stop / do not reopen unless new evidence appears
- Treating Bayān as automatically a scribal corruption.
- Treating Georgius as continuous al-Ḥīra episcopal succession.
- Treating network survival as centralized Tayyite command.
- Treating silence in a source as proof of nonexistence.
- Repeating generic “mainstream narrative is Hijazi-centric” claims without corpus-level demonstration.
- Repeating “historiographical erasure” claims without direct transmission evidence.
- Reopening the B/H phonetic-drift tangent.
