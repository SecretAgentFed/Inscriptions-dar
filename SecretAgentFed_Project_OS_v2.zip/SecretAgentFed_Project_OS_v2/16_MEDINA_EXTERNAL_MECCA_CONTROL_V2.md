# MEDINA / EXTERNAL WITNESSES / MECCA CONTROL

## Medina
Controlled material includes Salʿ evidence, Sadd al-Khanaq, Wādī Rānūnā, and the Rāshid/Imbert epigraphic branch. Treat physical memory as independent evidence rather than illustration of literary claims.

## External witnesses
Priority is to extract exact wording, date, manuscript tradition, and what the witness actually identifies: ruler, military leader, title, place, event, or religious category.

## Mecca
Mecca remains a sacred/home axis in the project model, but geographic/sacred centrality should not be assumed to equal political capital at every stage.

## Rule
External evidence should be used to constrain the model before being used to confirm the model.
