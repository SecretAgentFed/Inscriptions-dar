# AL-ḤĪRA OBJECT CORPUS — CONTROL

## Current corpus
Rice 1931 al-Ḥīra; Rice 1932 *Antiquity*; Rice 1934 *Ars Islamica*; Mundell 1977; V&A and Ashmolean object records.

## Controlled examples
- EAX.6004 — approximately 15 cm × 9.5 cm thick; Building I / Mounds I–II; Fig. 8b/8; horseshoe arcade; whitewash/straw-mat.
- V&A A.30-1932 — approximately 14.6 × 11.4 cm; Fig. 8e; morphological parallel, not a proven join.
- EAX.6007 / 6016 — candidate Ashmolean cross-fragments.
- Mundell Fig. 11e / 11h — fresco/reconstruction material.

## Rule
Object similarity is not physical identity. A morphological parallel is not a join.

## Next step
Create object-level cards with repository ID, dimensions, provenience, excavation context, figure number, publication, image, and confidence of identification.
