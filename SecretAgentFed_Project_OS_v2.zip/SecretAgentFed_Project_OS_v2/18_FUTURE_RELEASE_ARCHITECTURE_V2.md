# FUTURE RELEASE ARCHITECTURE

## Phase 1 — Control and correction
Use LXXIV/LXXVII-style control documents to lock known facts, corrections, and unresolved issues.

## Phase 2 — House of Iyas / al-Ḥīra
Publish only after the prosopographical and surrender-variant tables are complete enough to distinguish A/B/C claims.

## Phase 3 — Transmission problem
Bayān / Iyās / Farwah / Ḥayyah should be treated as a textual-history release, not merely genealogy.

## Phase 4 — External succession
Build the external-witness ledger before making a major Muhammad/title/king-prophet synthesis.

## Phase 5 — Institutional transition
Connect al-Ḥīra, Medina, Jerusalem, Damascus, churches, schools, property and fiscal systems without collapsing their functions.

## Phase 6 — Synthesis
Only after the evidence graph is stable should the project publish its broadest causal formulation.
