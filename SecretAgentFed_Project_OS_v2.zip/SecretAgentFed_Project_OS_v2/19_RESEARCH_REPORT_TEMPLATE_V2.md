# RESEARCH RETURN TEMPLATE

## Research question

## Why this question is live

## Sources actually opened

## Exact passages extracted

## Direct findings

## Claim(s) affected

## Evidence grade
A / B / C

## Correction Ledger interactions
CL-___

## Atlas interactions
AT-___

## Counterevidence

## Negative controls

## Identity/date uncertainties

## What this does NOT prove

## Recommended next action

## Publication relevance

## Source-state
IDENTIFIED / LOCATED / OPENED / EXTRACTED / PASSAGE-CONTROLLED / CLAIM-LINKED / COUNTEREVIDENCE-REVIEWED
