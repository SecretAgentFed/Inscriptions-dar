# AGENT OPERATING PROTOCOL — v2

Before research:
1. Read Master State.
2. Read the relevant Correction Ledger domain.
3. Read the relevant Atlas branch.
4. Read Open Questions / Stop List.
5. Search existing publication material before opening new broad literature.

During research:
- preserve exact quotations;
- record edition/page/URL;
- distinguish reported from extracted;
- record counterevidence;
- maintain person/office/seat/locus separation;
- never silently repair malformed source data;
- never turn a project publication into independent corroboration.

After research:
- state exactly what changed;
- state what remains unresolved;
- state which claims were strengthened/weakened;
- assign source-state labels;
- recommend one next action, not a cloud of unrelated leads.
