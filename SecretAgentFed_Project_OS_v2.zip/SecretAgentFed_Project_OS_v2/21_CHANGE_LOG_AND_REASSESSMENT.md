# REASSESSMENT — WHY v2 IS BETTER

The earlier Project Control Pack was useful but too much of a scaffold. The Perplexity-State pack improved it, but still left several problems.

## Problems identified
1. The two packs duplicated one another without a clear master hierarchy.
2. The Perplexity reconstruction and historical thesis were not sharply separated.
3. Source identity, source opening, passage extraction, and claim support were too easily conflated.
4. The 680-entry Correction Ledger was summarized but not made machine-addressable.
5. The 577-reference layer was controlled conceptually but lacked a clearly labeled derivative extraction file.
6. The publication evolution was too compressed.
7. The session archive contained richer research architecture than the control pack exposed.
8. “Current state” needed to distinguish public publication state from historical evidence state.

## v2 correction
This OS makes those distinctions explicit and puts the recovered artifacts beneath the control layer.

## Desired endpoint
A future agent should be able to answer three separate questions:

**A. What does the project currently argue?**
Use Master State / Claim Control.

**B. What does the evidence actually control?**
Use Correction Ledger / Atlas / source-state records.

**C. What did the prior AI research operation actually do?**
Use Perplexity reconstruction / session map / 577-resource forensic controls.

Those three answers must never be silently merged.
