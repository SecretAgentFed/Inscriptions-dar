# PROVENANCE MATRIX SCHEMA

| Field | Meaning |
|---|---|
| SRC-ID | stable source/resource identifier |
| raw_reference | immutable raw URL/string |
| candidate_resource | normalized candidate identity, if any |
| resource_state | identified/located/opened/extracted/etc. |
| source_type | primary/secondary/internal/archive/noise |
| passage | exact controlled passage |
| page/location | page, line, inscription no., object no., etc. |
| claim_ids | claims affected |
| evidence_grade | A/B/C |
| correction_ids | CL entries affected |
| atlas_ids | Atlas items affected |
| counterevidence | strongest contrary material |
| identity_confidence | high/medium/low/unresolved |
| date_confidence | high/medium/low/unresolved |
| used_by_perplexity | direct/structural/unknown |
| notes | free controlled notes |

Do not delete old states. Append corrections and supersession relationships.
