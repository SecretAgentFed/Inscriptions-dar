# AGENT BOOT SEQUENCE

1. Read `00_README.md`.
2. Read `01_MASTER_STATE_V2.md`.
3. Read `02_EVIDENCE_AND_SOURCE_HIERARCHY.md`.
4. Read `04_PERPLEXITY_OPERATION_RECONSTRUCTION_V2.md`.
5. Read `10_CORRECTION_LEDGER_OPERATING_STATE_V2.md`.
6. Read `11_ATLAS_OPERATING_STATE_V2.md`.
7. Read the branch control file matching the requested task.
8. Read `15_OPEN_QUESTIONS_AND_STOP_LIST_V2.md`.
9. Only then search external sources.

The agent must return its work using `19_RESEARCH_REPORT_TEMPLATE_V2.md`.
