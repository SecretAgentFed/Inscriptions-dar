# MASTER HANDOFF

You are entering an active historical research project whose evidence architecture is larger than its public narrative.

The project has:
- a long publication series;
- a 680-entry Correction Ledger;
- an Evidence Atlas;
- a 577-occurrence Perplexity reference layer;
- a recovered Perplexity session/archive;
- extensive branch-specific research files.

Your job is not to restart the research. Your job is to **continue from the controlled state**.

Do not flatten competing evidence. Do not silently normalize source anomalies. Do not promote project hypotheses to facts. Do not reopen questions already controlled unless new evidence appears.

The highest-value contribution is usually one of:
1. closing an open prosopographical gap;
2. extracting a missing primary passage;
3. resolving a source-identity problem;
4. identifying decisive counterevidence;
5. linking a claim to a controlled passage;
6. correcting a publication claim against the Ledger/Atlas.
