# SOURCE CUSTODY RULES

## Preserve
- original filenames
- raw URLs
- exact quotations
- page numbers
- edition information
- source variants
- correction history

## Never silently change
- names
- dates
- URLs
- transliterations inside controlled quotations
- source identity
- genealogical relationships
- inscription dates

## If an OCR/PDF artifact is malformed
Record:
1. raw form
2. observed anomaly
3. candidate reconstruction, if any
4. confidence
5. verification source

The candidate reconstruction never replaces the raw form.
