# STATUS DASHBOARD

## GREEN / controlled infrastructure
- 680-entry Correction Ledger recovered.
- Atlas sourcebook and research companion recovered.
- Perplexity export recovered.
- 577-reference layer accounted for.
- Current public archive confirmed through LXXVIII.
- House of Iyas / Farwah control state established.

## AMBER / requires continued work
- 185 candidate resource provenance.
- Full publication-by-publication claim reconciliation.
- External witness passage extraction.
- Complete Bayān/Iyās textual collation.
- Full 633 surrender variant table.

## RED / highest research value
- exact 618–633 gap controls;
- Iyas/Farwah/Ḥayyah/Hāniʾ prosopography;
- Bayān transmission problem;
- independent external succession/title evidence;
- claim-level reconciliation between current publications and controlled evidence.
