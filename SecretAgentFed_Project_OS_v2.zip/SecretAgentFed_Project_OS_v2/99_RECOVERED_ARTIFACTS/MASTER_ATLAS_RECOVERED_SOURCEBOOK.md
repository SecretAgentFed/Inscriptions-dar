# THE ATLAS — COMPLETE RECOVERED MASTER SOURCEBOOK

## Status
This file consolidates the recoverable Atlas source material currently available in the working file corpus. It is the underlying research/sourcebook, not a claim that every unresolved source has been independently inspected.

## Master architecture
1. Title / Editorial Note / Method
2. Medina Evidence
3. Kamna / Kaminahū
4. Nabaṭʿalī Dossier
5. Political / Religious / Hydraulic Networks
6. Chronology and Synchronisms
7. Evidence Gaps / Confidence Register
8. Master Synthesis / Conclusion

## Supporting layers
- A–Z Evidence Cards
- House of Iyas / al-Ḥīra dossier
- Tayy → Ridda → Iraq → Kufa integration
- Dual Tayyite Corridor
- Absorption Principle
- Medina evidence register
- Kamna/Kaminahū inscription corpus
- Nabaṭʿalī dossier
- political/religious/hydraulic networks
- chronology/synchronisms
- source-control register
- negative-control register
- confidence/gap register
- Mecca/qibla evidence matrix
- early Muhammad corpus
- covenant/authority/kingship architecture

---

# RECOVERED SOURCE MATERIAL — SESSION ARCHIVE

THE TAYYITE SUCCESSION — VISIBLE SESSION ARCHIVE
Created from the visible/recoverable text available in this ChatGPT session.
IMPORTANT: This archive contains no hidden/system/developer/model-secret text. It does not claim to be a raw export of the entire ChatGPT transcript; it preserves the actual draft files recoverable from the session and a visible-session reconstruction/index below.
VISIBLE SESSION RECONSTRUCTION / INDEX

Project: The Tayyite Succession: How Muhammad Came to Power
Current publication arc discussed in the session:
XLI. The Family That Opened the Gates
XLII. The Southern Input: Musaylima, Raḥmān, and the Bakr Corridor
XLIII. Eight Documents, One Biography: Serjeant and the Composite Covenant
XLIV. The Twelve-Year Gap and the Consolidation of the Network
XLV. The Collective Kingdom, the Sacred Seat, and the Rise of the King (master working draft discussed in session)
XLVI. Non-Muslim succession lists / Serjeant composite-covenant material (planned)

RECOVERED THREADS DISCUSSED IN THE SESSION

Iyas / al-Ḥīra: Iyas b. Qabīsa al-Ṭāʾī, al-Ḥīra, Āzāḏbeh, Naḵīragān, ʿAyn al-Tamr, Dū Qār, the White Palace, and the 633 surrender.
Expansion: The expansion was treated as a pivot: the original political project expanded beyond its initial goals; successful conquest created additional commanders, territories, revenues, military centers, and potential rival kings.
Egypt: Egypt was identified as changing the scale of the problem. Traditions concerning ʿAmr b. al-ʿĀṣ and ʿUmar preserve an authorization question; Alexandria/Fusṭāṭ was discussed as a capital/commander-control analogy.
Gates / local networks: A recurring mechanism was discussed: opening gates, local elites, information, negotiated surrender, taxation, military centers, and onward expansion. “Spies everywhere” was treated as a structural hypothesis about local information networks, not proof of a centralized intelligence service.
Southern covenant: The session explored a southern Abrahamic political-religious vocabulary, including Himyar, Raḥmānān, and the possibility of a “new Israel” style covenantal claim being reassigned northward.
Bismillah / Raḥmān: The session specifically identified the significance of the earlier dual divine terminology and its possible northward migration/reformulation into later Islamic formulae. This was treated as a research question rather than a settled derivation.
Abraha: Abraha was used as the southern political-religious background. The “school of prophets” idea was rejected as unsupported; epigraphic Raḥmānān evidence and the 2025 Nāʿiṭ fragment were retained as stronger evidence.
Medina covenant: The Constitution of Medina was discussed as potentially preserving a political covenant broader than the later confessional community, with Jewish-identifying groups participating without requiring identical religious identity.
Jewish component: The three famous Jewish tribes were treated as a later memory problem; the session explored whether political rupture may later have been remembered as religious betrayal. The “southern half” idea was retained only as a hypothesis.
Circumcision: Circumcision was discussed as an Abrahamic practice shared across communities, making it an unreliable simple Jewish/non-Jewish boundary. No evidence was established that it was explicitly a Medina membership condition.
Prophet / king: The session developed a reconstruction in which sacred/religious authority could survive the founder’s death while military commanders fought. The surviving sacred authority could therefore become politically threatening because reunification might create another king.
Civil war / memory: The proposed memory mechanism was founder’s death → constitutional crisis → warlords continue → surviving prophet/religious authority becomes politically dangerous → political conflict becomes “false prophet”/betrayal memory → dead founder is rehabilitated after settlement.
Muʿāwiya / Jerusalem / Damascus: The Maronite Chronicle’s Jerusalem ceremony and statement that Muʿāwiya placed his political seat in Damascus were used to build the distinction: al-Ḥīra = older political capital; Jerusalem = sacred/ceremonial center; Damascus = new imperial capital.
Lost capital: The closing argument was corrected to avoid making “throne” the conceptual endpoint. The intended conclusion is that the older political capital may have disappeared from later memory; the capital did not simply move, but the memory of the original capital was lost.

RECOVERED DRAFT FILES — FULL TEXT


================================================================================
FILE: XLIV_The_Twelve-Year_Gap_and_the_Consolidation_of_the_Network.txt
================================================================================

XLIV. THE TWELVE-YEAR GAP AND THE CONSOLIDATION OF THE NETWORK

Iyas, ʿAyn al-Tamr, and the Problem of the Missing Years

The Tayyite Succession Series


I. THE QUESTION AFTER IYAS

The previous installments have established a structural problem that the conventional chronology does not fully resolve.

Iyas b. Qabīṣa al-Ṭāʾī appears in the sources as a political figure operating at the intersection of al-Ḥīra, the Sasanian court, and the Arab frontier.

Yet the chronology traditionally constructed from the Arabic histories seems to make his career disappear into a simple succession:

Lakhmid monarchy ends

↓

Iyas b. Qabīṣa al-Ṭāʾī

↓

Āzāḏbeh b. Bānegān

↓

al-Mundhir b. al-Nuʿmān

↓

Arab conquest of al-Ḥīra

On paper, the sequence is straightforward.

The surviving traditions are not.

They preserve Iyas in connection with a second geographical center: ʿAyn al-Tamr and the Euphrates frontier.

They preserve correspondence between Iyas and Khosrow.

They preserve Iyas advising the Persian king about Bakr b. Wāʾil.

They preserve a deliberate withdrawal by Iyas from Khosrow toward ʿAyn al-Tamr.

They preserve coordinated Arab defection within the Persian coalition at Dū Qār.

And, most strikingly, one of the conquest narratives places Iyas himself inside the White Palace at al-Ḥīra in 633, after Āzāḏbeh has fled.

The problem, therefore, is not simply where Iyas went.

The problem is whether the traditional chronology has mistaken the succession of offices for the disappearance and reappearance of the people and networks who occupied them.

The “twelve-year gap” should therefore be understood as a historiographical problem: a period in which the surviving narrative gives us a sequence of offices and rulers, while other traditions preserve evidence of continuing personnel, territory, family connections, political functions, and covert realignment.

The gap may not have been empty.

It may be where the network becomes hardest to see.


II. THE FLIGHT FROM KHOSROW

The Dū Qār traditions preserve one of the most revealing episodes in the Iyas dossier.

After the defeat of the Persian forces, Iyas returns to Khosrow II.

He gives the king a false report of the battle, representing the Persian side as victorious.

He then asks permission to leave, claiming that his brother Qays b. Qabīṣa is ill at ʿAyn al-Tamr.

The source then explicitly explains the deception:

وَإِنَّمَا أَرَادَ أَنْ يَتَنَحَّى عَنْهُ

“He intended instead to withdraw from him.”

The distinction matters.

The story does not merely say that Iyas was dismissed, replaced, or sent away.

It preserves a memory of Iyas deliberately removing himself from the immediate reach of the Persian king.

A poem attributed to Iyas is introduced with the phrase:

قاله وقد هرب من كسرى

“He said it when he fled from Khosrow.”

The attribution of the poem cannot simply be assumed to be authentic.

But the combination of the narrative and the poetic heading preserves a consistent historiographical motif: Iyas escaping from direct Sasanian control and moving toward ʿAyn al-Tamr.

That makes ʿAyn al-Tamr more than a convenient place-name in the story.

It becomes a possible second center of Iyas's political geography.

But there is an even larger question.

Why did Iyas need to escape from Khosrow at all?

The answer becomes more significant when the Dū Qār battlefield tradition is placed beside the story of his withdrawal.

Iyas had occupied a position inside the Persian frontier system.

Arab forces associated with that system then secretly coordinated with the opposing Arab forces.

The Persian army was defeated.

Iyas survived.

And immediately afterward, rather than defending himself before Khosrow with an honest account, he concealed the defeat and used the deception to withdraw.

The sequence is difficult to understand as the behavior of a straightforwardly loyal Persian commander.

It becomes considerably more intelligible if Iyas is reconstructed as a political actor who had already begun shifting his allegiance toward an emerging Arab order while remaining inside the Persian system.

That is a reconstruction, not a direct statement preserved by the sources.

But the pattern deserves to be stated plainly.

Iyas appears to have been in a position to suppress the Arab opposition.

Instead, the traditions preserve an Arab victory, his survival, his deception of Khosrow, and his withdrawal toward an Arab-controlled frontier sphere.

The possibility that he deliberately enabled rather than merely suffered the Arab victory cannot be dismissed as an accidental reading of the evidence.


III. THE DŪ QĀR BETRAYAL

The most important evidence for this reconstruction comes from the conduct of the Arab auxiliaries themselves.

The Dū Qār traditions do not describe the Arab defection as a spontaneous moment of battlefield panic.

The Iyād auxiliaries secretly communicate with Bakr before the battle.

They ask whether they should flee during the night or remain until the fighting begins.

Bakr instructs them to remain and then flee when the battle is joined.

When the battle takes place, the concealed Arab force under Yazīd b. Himār attacks, the Iyād contingent turns and flees as previously arranged, and the Persian side collapses.

This matters enormously.

The “betrayal” was not simply a soldier deciding in the heat of battle that he preferred the other side.

It was coordinated beforehand.

Arab forces operating within the Persian coalition had established communication with the Arab forces opposing it and arranged their withdrawal.

The surviving tradition therefore gives us something very close to a covert operation inside the Persian military system.

The sources do not explicitly say that Iyas personally issued the order.

That distinction must remain.

But Iyas was the senior Arab political figure occupying the relevant frontier position.

He knew the Arab tribes.

He knew Bakr b. Wāʾil.

He was consulted by Khosrow about how to deal with them.

He was responsible for Arab forces operating within the Persian system.

And he subsequently survived the defeat and deceived the very king whose forces had been defeated.

The question therefore becomes unavoidable:

If Iyas were genuinely committed to suppressing the Arab uprising, why did the Arab forces inside his own coalition receive the opportunity to coordinate their withdrawal and survive?

A loyal commander would have had an obvious reason to prevent that outcome.

The surviving narrative instead gives us the opposite outcome.

The Arab forces win.

The Persian side loses.

Iyas survives.

And Iyas then lies to Khosrow and withdraws.

The historical reconstruction that best connects these facts is not necessarily that Iyas personally directed every movement on the battlefield.

It is that Iyas may have used his position within the Persian frontier system to permit, facilitate, or coordinate an Arab realignment against Persian authority while maintaining his cover inside the imperial system.

In modern analytical language, this resembles the role of a double agent.

The term is ours, not the source's.

The underlying behavior is what matters.


IV. WHY WOULD IYAS DO THIS?

The question becomes more interesting when the political consequences of Dū Qār are considered.

The victory was not merely the defeat of one Persian expedition.

It became embedded in Arab memory as a decisive victory over Persian power and as part of a larger transformation in Arab political confidence.

If Iyas had simply been trying to save himself, there were other possibilities.

He could have attempted to suppress the Arab forces.

He could have ensured that the Arab auxiliaries inside the Persian coalition remained loyal.

He could have allowed the opposing Arab forces to be destroyed.

Instead, the surviving tradition gives us coordinated Arab defection, Persian defeat, Iyas's survival, and his subsequent deception of Khosrow.

This raises a more consequential possibility.

Iyas may have understood that the political future of the Arab frontier was changing and acted to ensure that Arab forces survived the transition.

In that reconstruction, his actions at Dū Qār were not simply an act of personal escape.

They were a political choice.

He did not have to destroy the Arab forces opposing Persia.

He appears instead to have allowed the Arab side to win while preserving his own ability to remain inside the political system long enough to withdraw safely.

That would explain an otherwise remarkable combination of facts:

the Arab uprising succeeds,

the Arab auxiliaries survive,

Iyas survives,

and Iyas escapes Persian retaliation.

The most economical reconstruction is therefore that Iyas was not merely caught between two sides.

He was playing both sides.

He remained within the Persian information sphere while helping the Arab side.

He possessed the information necessary to understand Persian intentions.

He possessed relationships with the Arab forces opposing Persia.

And he possessed enough authority to influence what happened to Arab forces operating under the Persian command structure.

This is precisely why the Dū Qār episode deserves to be reconsidered as a possible turning point in the political history of the Arab frontier.

Dū Qār may not have been merely an Arab revolt that Iyas failed to suppress.

It may have been the moment when an Arab frontier ruler used the machinery of the empire that employed him to help break the empire's control over the Arabs.


V. ʿAYN AL-TAMR AND THE EUPHRATES BASE

The traditions surrounding Iyas preserve an unusually concrete connection to ʿAyn al-Tamr.

Khosrow is said to have granted Iyas thirty villages along the Euphrates for life and appointed him administrator over ʿAyn al-Tamr and the surrounding territory toward al-Ḥīra.

Ṭabarī's material likewise preserves the connection between Iyas, the Euphrates villages, and the administration of ʿAyn al-Tamr.

His brother Qays b. Qabīṣa is also associated with ʿAyn al-Tamr.

Later traditions even place Iyas's death there.

Taken together, these traditions suggest that the Qabīṣa family's relationship with ʿAyn al-Tamr was not incidental.

Jawād ʿAlī and Michael Lecker both draw attention to the significance of this Euphrates connection in reconstructing the Qabīṣa family's position.

The important distinction is between two kinds of authority.

Al-Ḥīra represented a formal political office embedded within the Sasanian frontier system.

ʿAyn al-Tamr represented a territorial and familial sphere in which Iyas and his relatives appear to have possessed an established position.

We do not need to assume that the latter was an independent kingdom.

We only need to recognize that losing one office did not necessarily eliminate every other source of authority.

This provides a plausible mechanism for understanding how Iyas could disappear from one administrative sequence without disappearing from the frontier itself.


VI. IYAS AS A FRONTIER INTERMEDIARY

The Dū Qār traditions preserve another important feature of Iyas's career: correspondence.

Khosrow asks Iyas about the property of the former Lakhmid king al-Nuʿmān.

Iyas explains that the property had been placed in the protection of Bakr b. Wāʾil.

He then communicates with Hāniʾ b. Masʿūd, demanding its return.

The chain is explicit:

Khosrow

↓

Iyas b. Qabīṣa

↓

Hāniʾ b. Masʿūd

↓

Bakr b. Wāʾil

↓

Iyas

↓

Khosrow

The same body of tradition depicts Khosrow consulting Iyas about how to deal with Bakr b. Wāʾil.

Iyas advises the king to conceal the purpose of his movement, place informants among the Arabs, and wait for a suitable opportunity.

The narrative explicitly describes Iyas as:

عامله على عين التمر وما والاها

“his official over ʿAyn al-Tamr and what lay around it.”

Whether every detail of these stories preserves a verbatim seventh-century exchange cannot be established.

But their institutional structure is important.

Iyas is not portrayed merely as a ceremonial ruler of al-Ḥīra.

He appears as an intermediary between an imperial court and Arab frontier communities.

That role requires information.

It requires correspondence.

It requires knowledge of tribal relationships.

And it requires access to territorial networks extending beyond the walls of al-Ḥīra.

This makes the Dū Qār episode more significant.

The man advising Khosrow about how to penetrate the Arab coalition was himself embedded within that Arab political world.

He was therefore uniquely positioned to understand both sides.

If he then used that position to allow Arab forces to defeat the Persian coalition, his role begins to look less like passive mediation and more like deliberate political manipulation of the imperial system from within.


VII. THE CHRONOLOGICAL GHOST

The instability becomes even clearer when the reported duration of Iyas's rule is compared across the sources.

The traditions do not agree.

One chronology associated with Hishām b. Muḥammad al-Kalbī and preserved by Ṭabarī gives Iyas nine years at al-Ḥīra.

Another tradition associated with al-Dīnawarī gives a much shorter period.

Ibn al-Athīr preserves a fourteen-year figure in another chronological construction.

The point is not that one number can simply be selected and the others discarded.

The point is that the chronology itself is unstable.

And this instability becomes more significant because Iyas is accompanied in some traditions by a Persian official whose name appears in several forms: al-Hamarjān, al-Baḥrajān, al-Nakhr(a)jān, al-Takhr(a)jān and related variants.

Jawād ʿAlī, following earlier work by Theodor Nöldeke and Gustav Rothstein, makes a methodological observation of considerable importance: the term may originally have designated an office or position that later narrative transmission treated as the proper name of an individual.

In other words, an institutional title may have become a person.

That possibility gives us a useful warning.

The Arabic king-lists may not always be preserving biographies in the modern sense.

They may be converting administrative structures into sequences of named rulers.

And if that happened here, then overlapping jurisdictions could later appear as successive reigns.


VIII. THE PROBLEM OF ĀZĀḎBEH

The traditional chronology next gives us Āzāḏbeh b. Bānegān, a dehqān of Hamadān and marzbān of al-Ḥīra.

Encyclopaedia Iranica summarizes the tradition from Ṭabarī: Āzāḏbeh governed al-Ḥīra for seventeen years after Iyas b. Qabīṣa and the Persian co-ruler Naḵīragān.

Because Āzāḏbeh was killed in 633, the beginning of his tenure is normally placed around 617 or 618.

At first glance, this seems to close the problem.

Iyas disappears.

Āzāḏbeh takes his place.

Seventeen years pass.

Then the Arabs arrive.

But the detailed chronology preserved by Ṭabarī is more complicated than the familiar shorthand suggests.

It divides Āzāḏbeh's seventeen years among several Sasanian reigns:

fourteen years and eight months under Khosrow II,

eight months under Šērōya,

one year and seven months under Ardašīr III,

and one month under Būrān.

The same chronology then gives al-Mundhir b. al-Nuʿmān another eight months before the arrival of Khālid b. al-Walīd.

This matters.

The traditional seventeen-year figure does not actually place Āzāḏbeh continuously in office until the instant of the conquest.

It places a seventeen-year period before a further eight-month period associated with al-Mundhir.

The chronology therefore contains an internal layer that is often flattened in later summaries.

And that creates another question:

Who exactly was exercising authority at al-Ḥīra during those final months?

The answer is not as simple as the conventional succession table suggests.


IX. THE EIGHT-MONTH AL-MUNDHIR PROBLEM

The figure of al-Mundhir is itself unstable.

The tradition identifies him as al-Mundhir b. al-Nuʿmān, also called al-Ghurūr or al-Maʿrūr, and assigns him eight months before Khālid's arrival.

Some later accounts identify him with the Lakhmid restoration immediately preceding the conquest.

But other historical traditions place an al-Mundhir b. al-Nuʿmān in the events of the Ridda period in Bahrain, while modern discussions have noted the resulting confusion between the Lakhmid succession and the Bahrain episode.

This is not a minor chronological footnote.

It means that the apparent sequence

Āzāḏbeh → al-Mundhir → Khālid

cannot automatically be treated as a secure record of three cleanly bounded administrations of al-Ḥīra.

The eight-month figure may preserve a real political episode.

It may also preserve a conflation of separate traditions.

Either way, it belongs inside the problem rather than being used to solve it prematurely.


X. THE SASANIAN INTERREGNUM

The chronology becomes even more difficult when Āzāḏbeh's seventeen-year period is placed against the political history of the Sasanian Empire.

Khosrow II was overthrown and killed in 628.

What followed was a succession crisis involving multiple rulers, competing factions, military intervention, and rapidly changing authority before Yazdegerd III's accession.

We should not turn this into an argument that an Āzāḏbeh governorship was therefore impossible.

The sources explicitly preserve him as marzbān of al-Ḥīra across this period.

But the chronology does make one thing clear: “seventeen years of Āzāḏbeh” should not automatically be visualized as seventeen years of an isolated Persian official sitting continuously inside al-Ḥīra while the rest of the empire remained administratively stable.

The surviving evidence does not tell us how much time Āzāḏbeh personally spent at the city, how his authority was delegated, or how the frontier was administered during the civil wars.

Those questions remain open.

That uncertainty is precisely why the distinction between office, person, and network matters.

The Arabic histories remember Āzāḏbeh as the marzbān.

They preserve Iyas in another set of traditions as a continuing Arab political figure.

The evidence does not require us to collapse those two roles into a single linear succession in which the first man's disappearance erased the second man's influence.


XI. THE WHITE PALACE SEAM

The strongest surviving textual seam appears in the conquest narrative of 633.

When Khālid b. al-Walīd advances toward al-Ḥīra, Āzāḏbeh is described as the marzbān.

He establishes his forces outside the city and sends his son to interfere with the waterway.

The son is defeated and killed.

Āzāḏbeh then flees after receiving news of Ardašīr's death and the death of his son.

The sequence then changes.

The Persian marzbān has fled.

The city remains.

The inhabitants take refuge in their fortified palaces.

And one of those palaces contains Iyas.

Ibn al-Athīr's account states:

وكان ضرار بن الأزور محاصراً القصر الأبيض وفيه إياس بن قبيصة الطائي

“Ḍirār b. al-Azwar was besieging the White Palace, and in it was Iyas b. Qabīṣa al-Ṭāʾī.”

The same identification appears in other Arabic conquest traditions.

This is one of the most important pieces of evidence in the entire problem.

It does not prove that Iyas secretly controlled al-Ḥīra throughout Āzāḏbeh's seventeen-year tenure.

It does not prove that Āzāḏbeh and Iyas were allies.

It does not prove that the later historians deliberately falsified the chronology.

But it does establish something much narrower and more concrete:

The same historical tradition that remembers Āzāḏbeh as the Persian marzbān also places Iyas b. Qabīṣa al-Ṭāʾī physically inside the White Palace at the moment of the Arab conquest.

That cannot be explained away by simply saying that Iyas disappeared from the political landscape after 617.

He is there.

And the source names him.


XII. THE WHITE PALACE AND THE SUCCESSION PROBLEM

The sequence is therefore worth setting out without interpretation:

Āzāḏbeh is marzbān of al-Ḥīra.

↓

His son confronts Khālid's forces at the Euphrates.

↓

His son is killed.

↓

Āzāḏbeh flees.

↓

The inhabitants of al-Ḥīra fortify themselves in the palaces.

↓

Iyas b. Qabīṣa al-Ṭāʾī is in the White Palace.

↓

The palace leaders negotiate with Khālid.

This is not a clean story of one administration simply replacing another.

It is a story of layered political personnel.

The Persian official controls one level of authority.

Local elites remain inside the fortified compounds.

When the marzbān departs, those local elites negotiate directly with the incoming power.

That is exactly what a frontier system might look like when imperial authority collapses.

The important question is therefore no longer:

“Who was the one ruler of al-Ḥīra?”

The more productive question is:

“What different kinds of authority existed in al-Ḥīra and its surrounding frontier, and which of them survived the collapse of Sasanian control?”


XIII. THE 633 DELEGATION

The surrender traditions introduce a second layer of instability.

The delegation associated with the settlement of al-Ḥīra is not transmitted identically in every source.

Some versions name Iyas b. Qabīṣa.

Others preserve Farwa b. Iyas.

Another genealogical tradition gives Qabīṣa b. Iyas b. Ḥayya.

These variants should not be harmonized by force.

They are evidence of a prosopographical problem.

At the same time, they preserve a remarkable structural continuity: members of the same connected political family or network appear in the negotiation over the fate of al-Ḥīra.

The exact genealogy remains disputed.

The continuity of the family connection does not require us to resolve every genealogical discrepancy.


XIV. THE TERMS OF THE TRANSFER

The 633 settlement is equally important because it shows what political incorporation looked like on the ground.

The traditions preserve annual fiscal payments, protection for churches and fortified palaces, and an agreement involving information about Persian movements.

The surviving reports therefore depict negotiation rather than the simple destruction of the existing civic order.

The exact monetary figure varies among the traditions.

The precise legal terminology also varies.

But the broad structure is consistent: the inhabitants of al-Ḥīra accepted a new political authority in exchange for defined fiscal and security arrangements while their religious and physical institutions were substantially preserved.

The intelligence provision deserves particular attention.

It should not be turned into a claim that the Ḥīran elite had secretly been working for the future Islamic state.

There is no evidence for that.

The more historically useful observation is simpler.

The people who negotiated with Khālid possessed information about the frontier because they had been part of the frontier.

Under Sasanian rule, information moved through Arab intermediaries, tribal leaders, merchants, local rulers, and imperial officials.

After the conquest, the direction of that information changed.

The infrastructure did not necessarily disappear with the regime that had previously used it.


XV. THE PATTERN OF COVERT REALIGNMENT

At this point the Dū Qār and 633 evidence can be placed beside one another.

At Dū Qār, Arab auxiliaries operating within the Persian coalition secretly communicate with Bakr before the battle and arrange their withdrawal.

After the defeat, Iyas deceives Khosrow about the outcome and uses the opportunity to withdraw toward ʿAyn al-Tamr.

At Ḥīra in 633, members of the political milieu surrounding Iyas and his family appear in the transfer of the city to the new Arab authority.

The settlement then preserves an intelligence function directed against the Persians.

These are not identical events.

But they exhibit the same political mechanism:

access to the old system → possession of information → covert communication → controlled realignment → survival of personnel → transfer of usefulness to the new power.

The repetition matters.

The Dū Qār auxiliaries do not simply abandon the Persian army in an uncontrolled panic.

They communicate beforehand.

Iyas does not simply flee after losing a battle.

He first gives Khosrow a false account and then deliberately withdraws.

The later Ḥīra settlement does not simply erase the old frontier elite.

It incorporates local personnel and redirects their knowledge.

The result is a recognizable pattern of political transition.

The people who understood the Persian frontier could become the people who helped the new Arab authority operate it.

This is why the phrase “double agent” is useful as an analytical analogy.

It should not be mistaken for a title found in the sources.

But if an Arab commander remains inside the Persian information system while secretly facilitating the survival and victory of the Arab forces opposing Persia, then the functional resemblance is unmistakable.

The crucial point is not whether we can prove that Iyas personally dictated every movement at Dū Qār.

We cannot.

The stronger historical question is whether his position made this kind of covert realignment possible and whether the surviving narrative preserves enough evidence to reconstruct it.

The answer is yes.

And that changes the significance of Iyas.


XVI. IYAS AND THE ARAB UPRISING

The conventional reading tends to leave Iyas in an awkward position.

He is the Arab official appointed by the Persians.

Then the Arabs defeat the Persians.

His troops—or troops within the coalition he commanded—betray the Persian side.

Yet Iyas himself survives.

He then lies to Khosrow and withdraws.

If all of this is treated as a sequence of unrelated accidents, the story becomes remarkably strange.

If it is treated as deliberate political realignment, the sequence becomes coherent.

Iyas had a reason to understand the Arab side.

He had relationships with its leaders.

He had access to Persian plans.

He had authority over Arab forces.

He had a territorial base at ʿAyn al-Tamr.

And when the Persian position was defeated, he did not die defending it.

He escaped from the king he supposedly served.

The evidence therefore permits a much stronger reconstruction:

Iyas may have deliberately turned the position entrusted to him by the Sasanian state against the imperial power that appointed him.

Dū Qār may have been the decisive moment in that transformation.

Under this interpretation, Iyas's role was not simply to survive the collapse of Persian authority.

He helped make that collapse possible.

That is a much more consequential historical possibility than the conventional succession list allows.


XVII. THE FAMILY CONTINUES THE FUNCTION

The significance becomes greater if the later evidence involving Iyas's family is viewed through the same lens.

The 633 traditions preserve members of the Qabīṣa/Iyas family or associated political network in the negotiations surrounding al-Ḥīra.

The exact genealogy varies.

But the function is recognizable.

People who had operated within the old frontier system remain politically useful after the transfer of power.

And the settlement includes intelligence directed against the Persians.

The pattern is therefore not simply:

Iyas disappears.

His sons appear.

It is:

Iyas develops or inhabits a frontier political position.

↓

Arab forces inside the Persian system realign against Persia.

↓

Iyas survives the Persian defeat and withdraws from Khosrow.

↓

The Qabīṣa family remains embedded in the Euphrates/Ḥīra political environment.

↓

The old frontier information network becomes useful to the new Arab power.

This does not prove that Iyas's sons were consciously carrying out a secret plan devised years earlier by their father.

But it demonstrates why the family and network should be treated as a continuity rather than as disconnected names in different chronicles.

The same political world keeps reappearing.

The personnel changes allegiance.

The information changes direction.

The frontier survives the empire.


XVIII. THE NETWORK MODEL

The emerging picture can therefore be represented as two overlapping layers rather than a simple succession:

SASANIAN IMPERIAL LAYER

Khosrow II
│
├── Persian court
│
├── Marzbān of al-Ḥīra
│       │
│       └── Āzāḏbeh
│
└── Frontier administration

ARAB FRONTIER LAYER

Iyas b. Qabīṣa
│
├── Qabīṣa family
│
├── ʿAyn al-Tamr
│
├── Euphrates villages
│
├── Bakr b. Wāʾil connections
│
├── al-Ḥīra
│
└── tribal and diplomatic relationships

These layers should not be imagined as two hostile governments.

They overlapped.

Iyas himself appears within the Sasanian political system.

The Arab frontier elite could serve Persian interests while simultaneously preserving their own territorial and familial interests.

The Dū Qār evidence suggests that, at least at a crucial moment, those two loyalties could diverge.

That is the key to the apparent contradiction.

The network did not have to oppose Persia openly in order to begin transferring itself away from Persia.

It could operate inside the imperial system until the moment when the imperial system became vulnerable.


XIX. THE TWELVE YEARS

This gives the “missing years” a different meaning.

The interval after Iyas's formal position and before the final consolidation of the Islamic conquest does not have to be filled with an invented biography.

Nor should it be treated as empty simply because the surviving chronology is dominated by Persian officeholders.

The evidence instead suggests a period in which formal authority, territorial influence, family position, imperial administration, and Arab political organization could diverge.

That is precisely the kind of period in which later historians would have difficulty reconstructing who controlled what, when, and in which capacity.

The result is a narrative that compresses overlapping structures into successive rulers.

Iyas becomes a former ruler.

Āzāḏbeh becomes his successor.

Al-Mundhir becomes the restored Lakhmid.

Khālid becomes the conqueror.

But the White Palace tradition forces us to look underneath that sequence.

The people did not necessarily disappear when the titles changed.


XX. THE NETWORK SURVIVES THE OFFICE

This changes the meaning of the succession.

If Iyas's formal authority at al-Ḥīra ended, but his Euphrates connections remained, then the succession was not simply:

Iyas → Āzāḏbeh.

It may have been:

Lakhmid political order

↓

Sasanian reorganization

↓

overlapping Persian and Arab authorities

↓

surviving local families and territorial networks

↓

imperial collapse

↓

negotiated incorporation into the expanding Islamic state.

That model explains why the conquest narratives can simultaneously preserve two apparently contradictory facts:

Āzāḏbeh is the Persian marzbān.

Iyas is inside the White Palace.

They do not have to be mutually exclusive.

They may represent different layers of the same frontier system.


XXI. FROM SASANIAN FRONTIER TO ISLAMIC FRONTIER

The importance of al-Ḥīra in 633 therefore lies beyond the city's capture itself.

Khālid did not arrive at an empty administrative landscape.

He encountered fortified compounds, Christian institutions, local elites, Arab tribal relationships, Persian officials, agricultural settlements, river transport, established routes, and a population accustomed to negotiating with imperial power.

The first settlement therefore had to do more than end a siege.

It had to establish a new relationship between the conquerors and an existing frontier society.

That relationship included taxation.

It included security.

It included protection of religious institutions.

And it included information.

The new state could therefore inherit functions without inheriting the political ideology of the old state.

The machinery of the frontier could survive even when the empire that had maintained it did not.


XXII. WHAT KIND OF MAN WAS IYAS IN THIS TRANSITION?

The evidence now permits a more consequential question than the conventional chronology normally asks.

What did the Arab frontier make of a man like Iyas?

He was not simply an Arab who happened to serve Persia.

He occupied a position inside the Persian system precisely because he possessed authority among Arabs.

That made him useful to Persia.

But it also gave him something Persia could not manufacture: access to the people whose loyalty Persia needed.

At Dū Qār, the distinction became decisive.

If the Arab auxiliaries had been simply rebellious soldiers acting without political direction, the event would be easier to explain as a breakdown of discipline.

But the traditions preserve advance communication and coordinated withdrawal.

Iyas then survives the defeat, deceives Khosrow, and withdraws.

That sequence permits the reconstruction of an Arab political actor who understood that the old imperial order was becoming vulnerable and who used his position accordingly.

He could not openly declare for the Arab side while still inside the Persian system.

He did not need to.

His power lay precisely in remaining inside the system while redirecting its Arab-facing machinery.

That is why the double-agent analogy is historically useful.

# RECOVERED SOURCE MATERIAL — CURRENT ATLAS HANDOFF

SESSION HANDOFF — THE ATLAS

I am migrating an ongoing research project into this fresh ChatGPT session.

Your job is to continue the work, not restart it.

1. PROJECT

The project is an evidence-controlled historical research Atlas concerning early Arabian and early Islamic political, religious, genealogical, epigraphic, archaeological, and institutional networks.

The current product is called:

THE ATLAS

It is intended for eventual publication.

The Atlas is not simply a narrative. It is an evidence map showing:

- objects
- inscriptions
- people
- genealogies
- rulers
- institutions
- religious associations
- political relationships
- chronology
- hydraulic infrastructure
- diplomacy
- scholarly interpretations
- unresolved questions

The central methodological principle is:

«Preserve the evidence before constructing the story.»

The tree can change.

The underlying evidence must remain visible.

---

2. IMPORTANT WORKING RULE

Do NOT restart the research from the beginning.

Do NOT replace the existing Atlas with a new theoretical framework.

Do NOT silently rewrite established material.

Continue from the current state and improve it through targeted verification.

Where new evidence contradicts an earlier formulation, identify the correction explicitly rather than silently changing history.

---

3. EVIDENCE HIERARCHY

Use these grades consistently:

A — Directly Attested

Directly preserved or independently strongly controlled evidence.

B — Supported Interpretation

Supported by palaeography, genealogy, chronology, context, comparison, or multiple sources, but not directly demonstrated.

C — Unresolved

Possible, useful as a research lead, but not presently established.

Also maintain these distinctions:

Cited ≠ independently inspected

Reported ≠ controlled

Inscriptional date ≠ necessarily modern scholarly date

Same name ≠ same person

Scholarly interpretation ≠ primary evidence

Never upgrade an interpretation simply because it has been repeated.

---

4. CURRENT ATLAS STRUCTURE

The latest master Atlas has eight publication windows:

1. Title / Editorial Note / Method
2. Medina Evidence
3. Kamna / Kaminahū
4. Nabaṭʿalī Dossier
5. Political / Religious / Hydraulic Networks
6. Chronology and Synchronisms
7. Evidence Gaps / Confidence Register
8. Master Synthesis / Conclusion

These eight windows constitute the current near-publication master.

Do not discard them.

---

5. MEDINA — CURRENT STATE

The Medina section concerns early Islamic archaeological and epigraphic evidence.

The principal modern source is:

Saʿd b. ʿAbd al-ʿAzīz al-Rāshid, Dirāsāt fī al-āthār al-islāmiyya al-mubakkira bi-l-Madīna al-Munawwara, Riyadh, 2000/1421 AH.

An exact PDF copy was uploaded during the previous research session.

The file is:

“2501 - دراسات في الآثار الإسلامية المبكرة بالمدينة المنورة p.d.f كتاب 2268.PDF”

CRITICAL:

The uploaded scan is image-only and the file system could not extract its text or images. The system reported:

“No content (images or text) could be read from document…”

Therefore, DO NOT pretend that pages from that PDF were independently inspected.

The bibliographic identity of the book is secure.

The page-level visual audit is not yet secure.

---

6. MEDINA PRIORITY PAGES

The research had identified these as important recovery targets:

Rāshid pp. 45–60

Sadd al-Khanaq.

Rāshid pp. 68–75

Wādī Rānūnā material.

Rāshid pp. 88–156

Large unresolved page-audit block.

The correct next step is to recover or independently locate readable scans/images of these pages and compare:

- photographs
- readings
- dates
- personal names
- archaeological context
- Rāshid's interpretation
- later scholarship

Do not manufacture page-level evidence from secondary citations.

---

7. MEDINA — CONTROLLED BASELINE

Current working Medina register:

Mount Salʿ

MED-SALʿ-001
MED-SALʿ-002
MED-SALʿ-003
MED-SALʿ-004
MED-SALʿ-005
MED-SALʿ-006

Sadd al-Khanaq

MED-EARLY-001

Prophet's Mosque

MED-M-001
MED-M-002
MED-M-003

The Atlas currently treats this as the controlled Medina baseline.

---

8. SADD AL-KHANAQ

The Sadd al-Khanaq material is associated with:

- Muʿāwiya
- Abū Raddād
- ʿAbd Allāh b. ʿAbbās
- Kathīr b. al-Ṣalt
- Abū Mūsā

It concerns dam construction/administration and is important evidence for early Islamic political and administrative activity at Medina.

The Atlas does NOT use every reconstructed personal relationship as equally secure.

---

9. WĀDĪ RĀNŪNĀ

Rāshid contains material concerning the Wādī Rānūnā poetic inscription associated with:

Bashīr b. Muslim b. Bashīr

Current status:

documentary control established

independent object/plate recovery pending

---

10. KAMNA / KAMINAHŪ

The second major evidence environment is ancient Kamna/Kaminahū in the Jawf of Yemen.

This is a PRE-ISLAMIC evidence environment and must remain analytically separate from Medina.

The Kamna material contains evidence for:

- kingship
- genealogy
- religious institutions
- political conflict
- irrigation
- territorial redistribution
- diplomacy
- shared cult
- dynastic marriage
- relationships with Nashshān
- relationships with Sabaʾ

---

11. KAMNA CORPUS

The working corpus includes:

Kamna 1–22
Kamna 23
Kamna 24–25
Kamna 26
Kamna 27
Kamna 28–29
Kamna 30 A–B
Kamna 31
Kamna 32
Kamna 33
Kamna 34

The 2015 Arbach & Rossi publication is particularly important.

It publishes Kamna 30 A, B, 31, 32 and 33 and states that these inscriptions provide new synchronisms between Sabaean and Kamna rulers, permitting a more precise chronology for the second half of the eighth and beginning of the seventh centuries BCE.

---

12. KAMNA 28–29

Kamna 28–29 provide additional eighth-century evidence.

Kamna 29 includes:

Abīʾanas b. Farḫ

and religious references including:

Wadd

and

Aranyadaʿ

Aranyadaʿ is strongly associated with Nashshān.

The political interpretation involving Nashshān remains a reconstruction and should therefore remain at approximately B unless stronger direct evidence is recovered.

---

13. KAMNA / NASHSHĀN

Current working model:

competition → conflict → intervention → settlement

Do not simplify this into permanent conquest.

Religious geography may preserve evidence for political relationships, but religious association alone does not prove political sovereignty.

---

14. KAMNA / SABAʾ

The relationship changes over time.

Current model:

local political autonomy

↓

conflict / regional competition

↓

Sabaean intervention

↓

settlement

↓

renewed accommodation

↓

religious/dynastic rapprochement

This is a working historical model, not a claim that every stage is directly documented by one inscription.

---

15. KAMNA 30 A–B / 31 / 32 / 33

These are a major new chronological layer.

Arbach & Rossi's 2015 study is now incorporated into the Atlas.

It specifically states that these new inscriptions provide synchronisms between Sabaean and Kamna rulers and improve the chronology of the Jawf for the second half of the eighth and beginning of the seventh century BCE.

The next research phase should extract these inscriptions at line level wherever possible.

---

16. NABAṬʿALĪ DOSSIER

This is one of the most important unresolved areas.

Do NOT merge every Nabaṭʿalī.

Current separate nodes include:

Nabaṭʿalī Dhariḥān b. Yashhurmalik

Strong genealogical node.

Nabaṭʿalī Amar b. Ilīsamiʿ

Separate node pending chronological/palaeographic convergence.

Other Nabaṭʿalī occurrences

Remain unattached unless evidence connects them.

---

17. NABAṬʿALĪ GENEALOGY

Strong working chain:

Yashhurmalik

↓

Dhariḥān

↓

Nabaṭʿalī

Confidence:

A

Do not collapse this with other Nabaṭʿalī occurrences merely because of the name.

---

18. MṢM 3630 / WAQĪHʾAB

Nabaṭʿalī and Waqīhʾab are associated in the inscriptional record.

The earlier formulation that Waqīhʾab was definitely a “co-regent” was too strong.

Current status:

association = A

father-son interpretation = supported

co-regency = C/B

Do not use “co-regent” as established fact.

---

19. KAMNA 19

Kamna 19 contains another royal association involving Nabaṭʿalī.

The exact relationship remains unresolved.

Possible interpretations:

- dynastic relationship
- co-rule
- alliance
- subordinate relationship
- another institutional relationship

Do not force the identification.

This is a priority research target.

---

20. RÉS 3945 / HYDRAULIC NETWORK

RÉS 3945 is an important hydraulic-political node.

Working relationship:

Karibʾil Watar

↓

military/political action

↓

Malikwaqah irrigation system

↓

territorial/resource redistribution

↓

Nabaṭʿalī / Kaminahū

The hydraulic relationship is strong.

The identification of every Nabaṭʿalī in this network with other Nabaṭʿalīs remains a separate question.

---

21. RELIGIOUS NETWORK

Current Kamna religious nodes include:

- Madahwū
- Nabʿal
- ʿAthtar
- ʿAthtar dhū-Raḥbah
- Wadd
- Almaqah

Nashshān-linked:

- Aranyadaʿ

The Atlas distinguishes:

religious association

from

political sovereignty.

---

22. MADAHWŪ

Madahwū is strongly associated with Kaminahū.

The characterization of Madahwū as a “federal” or institutional deity is an interpretation.

Cultic association:

strong

Precise constitutional terminology:

B

---

23. KAMNA 26

Kamna 26 is an important institutional inscription.

It involves:

Nabaṭʿalī Dhariḥān

and a community/council of twelve.

The inscription connects royal authority, community, religious institutions, and divine authorization.

The exact constitutional meaning of the “community of twelve” remains B.

---

24. YM 10886

YM 10886 is important because it appears to connect:

transgression

↓

divine jurisdiction

↓

confession/penance

↓

restoration

It should be studied as a possible intersection of religious and political/social jurisdiction.

Do not automatically turn this into evidence for a centralized judiciary.

---

25. ALMAQAH / RELIGIOUS RAPPROCHEMENT

Later Kamna evidence associates Kamna and Sabaean actors with shared worship of Almaqah.

This coincides in the reconstruction with:

- political rapprochement
- fraternity
- dynastic marriage

Shared cult is strong evidence for religious overlap.

The exact political meaning remains B.

---

26. DYNASTIC MARRIAGE

The Kamna material has been interpreted as preserving a marriage between a Sabaean and a Kamniote.

Current Atlas formulation:

marriage → dynastic connection → political rapprochement

Confidence:

B

Do not upgrade this to proof of a formal treaty without direct textual support.

---

27. CHRONOLOGY

Current framework:

Eighth century BCE

Strong Kamna political/religious evidence.

Mid-eighth century BCE

Kamna/Nashshān conflict.

c. 715 BCE

Yathaʿʾamar Watar / Sabaean-Assyrian synchronism provides an important external chronological anchor.

Late eighth century BCE

Major Kamna/Sabaean synchronisms.

Early seventh century BCE

Continued Kamna/Sabaean synchronisms.

Later centuries

Evidence for continued Kaminahū political/institutional presence.

Do not create a perfectly continuous royal succession unless the evidence warrants it.

---

28. CURRENT PUBLICATION STATUS

The Atlas is:

near-publication-ready as an evidence atlas.

It is NOT yet a completely finished epigraphic critical edition.

Remaining work is targeted verification, not wholesale reconstruction.

---

29. MOST IMPORTANT OPEN TASKS

Work in this order unless new evidence changes the priority:

PRIORITY 1 — MEDINA / RĀSHID

Recover readable copies/images of:

- pp. 45–60
- pp. 68–75
- pp. 88–156

Compare photographs, readings, dates and later scholarship.

PRIORITY 2 — KAMNA 30 A–B / 31 / 32 / 33

Perform line-level extraction and identify every synchronism.

PRIORITY 3 — KAMNA 19

Resolve the Nabaṭʿalī-associated royal relationship if possible.

PRIORITY 4 — NABAṬʿALĪ CROSS-IDENTIFICATION

Reconcile:

- YM 8871 / Kamna 27
- MṢM 3630
- Kamna 26
- RÉS 3945
- Kamna 17 / al-Ḥarāshif material

without collapsing distinct people.

PRIORITY 5 — FINAL ATLAS GRAPH

Only after the above should the final relationship graph and publication tables be frozen.

---

30. STYLE / COLLABORATION RULE

I prefer direct research collaboration.

Do not fill responses with unnecessary disclaimers.

Do not repeatedly explain that evidence is uncertain when the Atlas already marks the uncertainty.

Do not dilute strong evidence with excessive caveating.

But DO preserve the A/B/C distinction.

If something is unproven, label it.

If something is directly established, let it stand.

If something is an imaginative research lead, keep it clearly separated from proof.

---

31. PUBLICATION VERSION CONTROL

The current Atlas consists of eight publication windows.

When editing them:

Do not silently rewrite substantive arguments.

If I say:

“add”

“append”

“update”

“incorporate”

then preserve the existing body unless I explicitly request restructuring.

If new evidence changes an earlier conclusion, show the change explicitly.

For publication formatting, I want clean copy-paste-ready sections.

---

32. WHAT I WANT FROM THIS NEW SESSION

First, acknowledge that you have absorbed this handoff.

Then:

1. Identify the exact point where the previous session stopped.
2. Do NOT restart the Atlas.
3. Do NOT produce another general summary.
4. Continue the next research priority.
5. Search primary/authoritative sources where possible.
6. Keep evidence, interpretation, and hypothesis visibly separate.
7. Update the Atlas only when the evidence justifies an update.
8. Maintain version control.

The immediate continuation point is:

RĀSHID/MEDINA PAGE RECOVERY + KAMNA 30 A–B / 31 / 32 / 33 LINE-LEVEL VERIFICATION.

Begin there.







THE ATLAS

Evidence Atlas of Early Islamic, Arabian, and Late Antique Political–Religious Networks

Updated Master Edition

---

Editorial Note

This Atlas is an evidence-controlled research instrument.

It does not attempt to eliminate uncertainty by converting hypotheses into facts. Instead, it maps persons, institutions, inscriptions, places, political relationships, religious institutions, genealogies, chronology, and scholarly interpretations according to the strength of the evidence presently available.

The Atlas therefore distinguishes between what an inscription directly states, what can be independently corroborated, what is a strong scholarly reconstruction, and what remains an unresolved research lead.

The underlying evidence remains visible.

---

1. Method

Every Atlas entry is evaluated according to five questions:

1. What is the primary object or source?
2. What does it directly establish?
3. What independent evidence corroborates it?
4. What interpretation has been proposed?
5. What remains unresolved?

The Atlas does not treat a secondary citation as equivalent to direct inspection of the primary object.

---

2. Evidence Grades

A — Directly Attested

The relationship, person, title, date, institution, or object is directly preserved or independently controlled at a high level.

B — Supported Interpretation

The interpretation is supported by palaeography, genealogy, chronology, contextual comparison, or multiple sources, but is not directly demonstrated.

C — Unresolved

The proposition remains possible or useful as a research lead but cannot presently be established.

---

3. Critical Controls

Cited does not mean extracted.

A modern scholar citing an inscription does not mean that the Atlas has independently inspected the original inscription or photograph.

Reported does not mean controlled.

A reported reading or dating remains provisional until its underlying evidence can be checked.

Inscriptional date does not automatically equal modern date.

The Atlas distinguishes dates appearing on an object from later scholarly dating or redating.

Same name does not mean same person.

Repeated names—particularly royal names—are maintained as separate nodes until genealogy, palaeography, chronology, and context justify identification.

Interpretation remains interpretation.

When a scholar proposes a political or religious explanation, the Atlas attributes that interpretation rather than silently converting it into fact.

---

4. Purpose

The Atlas is intended to make complex historical reconstruction auditable.

Its purpose is not merely to produce a narrative.

Its purpose is to show the evidence network from which a narrative may or may not legitimately be constructed.



II. MEDINA — EARLY ISLAMIC EPIGRAPHIC EVIDENCE

1. Al-Rāshid and the Medina Corpus

Saʿd b. ʿAbd al-ʿAzīz al-Rāshid's Dirāsāt fī al-āthār al-islāmiyya al-mubakkira bi-l-Madīna al-Munawwara was published in Riyadh in 2000/1421 AH as a 245-page first edition.

The work is a major component of the Medina archaeological and inscriptional evidence base.

The Atlas treats it as a primary research source while distinguishing bibliographic control from direct page-level control.

---

2. The Uploaded Rāshid Copy

The exact PDF used in the research workflow is the uploaded scan of:

Dirāsāt fī al-āthār al-islāmiyya al-mubakkira bi-l-Madīna al-Munawwara.

The present file system cannot extract either text or images from the uploaded document.

Therefore, the Atlas does not pretend to have independently inspected pages that remain inaccessible.

This is a publication-control issue, not evidence that the book itself is unavailable or irrelevant.

---

3. Sadd al-Khanaq

The Sadd al-Khanaq material is one of the principal early Medina inscriptional records.

The inscriptional context is associated with:

- Muʿāwiya
- Abū Raddād
- ʿAbd Allāh b. ʿAbbās
- Kathīr b. al-Ṣalt
- Abū Mūsā

The material concerns the construction/administration of a dam and therefore provides evidence for early Islamic political and administrative activity at Medina.

Rāshid's discussion of the dam occupies pp. 45–60.

The Atlas treats the object and its documentary context as controlled, while preserving uncertainty concerning individual reconstructed relationships.

---

4. Wādī Rānūnā

Rāshid's work also contains material concerning the Wādī Rānūnā poetic inscription attributed to:

Bashīr b. Muslim b. Bashīr.

The inscription belongs to the Medina regional epigraphic environment.

Current status:

Documentary control — established.

Independent object/plate recovery — pending.

---

5. Medina Corpus — Current Controlled Register

The current working register contains:

Mount Salʿ

MED-SALʿ-001
MED-SALʿ-002
MED-SALʿ-003
MED-SALʿ-004
MED-SALʿ-005
MED-SALʿ-006

Sadd al-Khanaq

MED-EARLY-001

Prophet's Mosque

MED-M-001
MED-M-002
MED-M-003

These records constitute the present controlled Medina baseline.

---

6. Medina Dated Evidence

The broader Medina inscriptional corpus contains securely dated early Islamic material as well as undated inscriptions whose chronology must be reconstructed through palaeography and context.

The Atlas therefore does not place all Medina inscriptions into a single chronological block.

Dated inscriptions remain dated.

Undated inscriptions remain undated.

Proposed dates remain proposed dates.

---

7. Medina's Historical Significance

The Medina evidence is important because it places early Islamic political and religious activity into a material environment:

- construction,
- administration,
- personal religious expression,
- public infrastructure,
- local elites,
- written commemoration.

The inscriptions therefore provide a documentary layer independent of later literary biography.

They do not, by themselves, establish every proposition subsequently made about the early Islamic polity.

---

8. Medina Research Gap

The largest remaining Medina publication-control problem is direct inspection of the inaccessible Rāshid scan.

Priority pages remain:

pp. 45–60 — Sadd al-Khanaq

pp. 68–75 — Wādī Rānūnā

pp. 88–156 — unresolved page-audit block

Until the relevant plates and readings are recovered, the Atlas retains the distinction between:

bibliographically established

and

page-level independently inspected.

---

9. Publication Rule

The Medina section is publication-ready as an evidence register, but not yet as a complete facsimile-based epigraphic edition.

That distinction is intentional.



III. KAMNA / KAMINAHŪ

1. The Political Entity

Kamna, or Kaminahū, was a political entity of the ancient Jawf.

Its inscriptional record preserves evidence for:

- kingship,
- genealogy,
- religious institutions,
- political conflict,
- irrigation,
- territorial redistribution,
- diplomacy,
- intermarriage,
- and changing relationships with Sabaʾ and Nashshān.

The evidence is especially rich for the eighth and early seventh centuries BCE.

---

2. The Corpus

The modern Kamna numbering incorporates:

- Kamna 1–22
- Kamna 23
- Kamna 24–25
- Kamna 26
- Kamna 27
- Kamna 28–29
- Kamna 30 A–B
- Kamna 31
- Kamna 32
- Kamna 33
- Kamna 34

The later archaeological synthesis explicitly records this development of the corpus.

# CONTROLLED COMPLETENESS NOTES

The following remain explicitly unresolved or incompletely inspected in the current research state:

- Rāshid Medina PDF: bibliographic identity secure; page-level visual audit remains incomplete.
- Rāshid priority ranges: pp.45–60, 68–75, 88–156 require direct image/page control where not already independently recovered.
- Medina object recovery and independent readings remain open for several records.
- Kamna 19 / RES 2897 requires careful separation of Halévy's copy, provenance, reconstruction, and later interpretation.
- K21 and related bridge material must remain separate from established Nabaṭʿalī identifications until controlled.
- Several Nabaṭʿalī identifications remain unresolved.
- Northern Syrian Tayy evidence remains weaker than the Ḥīra/Iraq/Kufa Tayy evidence.
- Ḥābis b. Saʿd remains a research lead rather than a securely demonstrated bridge.
- House of Iyas → later Kufa Tayy organizational continuity is not demonstrated.
- Centralized Tayyite organization is not demonstrated.
- Hypotheses concerning Muhammad as title, Petra, Mecca chronology, covenant transfer, and distributed kingship must remain explicitly graded as hypotheses or supported interpretations where appropriate.

# PUBLICATION CONTROL RULE
Previously published Substack pieces are not to be deleted or silently rewritten. The Atlas is the consolidated evidence architecture beneath and around them. The A–Z cards and integration layers are supporting research material unless explicitly converted into publication windows.
